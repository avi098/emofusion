1, python 3.11


2, need to install ffmpeg lib
    follow on the steps that in the link
        https://www.geeksforgeeks.org/how-to-install-ffmpeg-on-windows/

3, create Virtual Environment => python -m venv venv

4, Activate Virtual Environment => venv\Scripts\Activate
    Deactivate the Virtual Environment => deactivate (or) .\venv\Scripts\Deactivate

5, Install the requirements => pip install -r requirements.txt


The machine learning algorithm used in this code is a Long Short-Term Memory (LSTM) neural network

